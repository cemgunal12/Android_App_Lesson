
const inventory = [
    { id: 1, name: "Cola", price: 1.50, stock: 5 },
    { id: 2, name: "Chips", price: 1.25, stock: 10 },
    { id: 3, name: "Chocolate", price: 2.00, stock: 7 },
    { id: 4, name: "Water", price: 1.00, stock: 12 },
    { id: 5, name: "Gummy Bears", price: 1.75, stock: 0 } // Stoğu tükenmiş bir ürün
];

// değer değişecegi, için let ile tanımladk
let userWallet = 10;

// burada envatnetri görüntüleyecegiz
function displayInventory() {
    console.log("--- Vending Machine Inventory ---");
    inventory.forEach(item => {
    
        console.log(`ID: ${item.id} | Name: ${item.name} | Price: $${item.price.toFixed(2)} | Stock: ${item.stock}`);
    });
    console.log("-------------------------------");
}

console.log("Welcome! Here is what we have:");
displayInventory();

/*
// Satış Fonksiyonu
function vend(itemId, moneyInserted) {
    // Ürünü ID'ye göre buluyoruz[cite: 43].
    const selectedItem = inventory.find(item => item.id === itemId);

    // Kontroller
    // Ürün bulunamadı mı? [cite: 48]
    if (!selectedItem) {
        console.log("Error: Invalid selection. Please choose a valid ID.");
        return;
    }

    // Stokta var mı? [cite: 50]
    if (selectedItem.stock === 0) {
        console.log("Error: Sorry, this item is out of stock.");
        return;
    }

    // Para yeterli mi? [cite: 52]
    if (moneyInserted < selectedItem.price) {
        console.log(`Error: Insufficient funds. You inserted $${moneyInserted.toFixed(2)}, but the item costs $${selectedItem.price.toFixed(2)}.`);
        return;
    }

    // Adım 2.3: Başarılı Satış
    // Para üstünü hesapla[cite: 57, 59].
    const change = moneyInserted - selectedItem.price;
    // Stoğu azalt[cite: 58].
    selectedItem.stock--;
    // Cüzdanı güncelle: Harcanan parayı çıkar, para üstünü ekle[cite: 60].
    userWallet = userWallet - moneyInserted + change;

    console.log(`Vending... You got a ${selectedItem.name}!`);
    console.log(`Here is your change: $${change.toFixed(2)}`);
}
*/

// BU KISIMDA TEST EDECEGİZ
/*
console.log("\n--- Starting Transactions ---");
// Başarılı bir satın alma [cite: 64]
vend(1, 2.00); 
// Yetersiz bakiye testi [cite: 65]
vend(2, 1.00); 
// Geçersiz ID testi [cite: 66]
vend(99, 5.00);
// Stoğu tükenmiş ürün testi
vend(5, 2.00); 

console.log("\n--- Final State ---");
// Envanterin son durumunu gör[cite: 67].
displayInventory();
// Cüzdanın son durumunu gör[cite: 68].
console.log(`Final user wallet: $${userWallet.toFixed(2)}`);
*/

// BU KISIM GECİKMELİ OLAN KISIM - Asenkron `vend` Fonksiyonu
function vend(itemId, moneyInserted, callback) {
    console.log("...processing your request...");

    setTimeout(() => {
        const selectedItem = inventory.find(item => item.id === itemId);

        if (!selectedItem) {
            // Hata durumunda callback'in ilk parametresini Error nesnesi ile doldurmak için[cite: 77].
            return callback(new Error("Invalid selection. Please choose a valid ID."), null);
        }

        if (selectedItem.stock === 0) {
            return callback(new Error("Sorry, this item is out of stock."), null);
        }

        if (moneyInserted < selectedItem.price) {
            return callback(new Error(`Insufficient funds. You inserted $${moneyInserted.toFixed(2)}, but the item costs $${selectedItem.price.toFixed(2)}.`), null);
        }

        const change = moneyInserted - selectedItem.price;
        selectedItem.stock--;
        userWallet = userWallet - moneyInserted + change;

        const result = {
            item: selectedItem,
            change: change
        };

        // Başarılı durumda ilk parametre null, ikinci parametre sonuç verisi[cite: 78].
        callback(null, result);
    }, 1000); // 1 saniye gecikme
}
//  Callback İşleyici Fonksiyonu
function handleVendResult(error, result) {
    if (error) {
        // Hata varsa, hata mesajını konsola yazdır.
        console.error("VENDING ERROR: " + error.message);
    } else {
        // Hata yoksa, başarılı sonuç detaylarını yazdır.
        console.log(`SUCCESS! You got a ${result.item.name}.`);
        console.log(`Your change is $${result.change.toFixed(2)}`);
    }

    console.log("\n--- Machine's Final State ---");
    displayInventory();
    console.log(`Final user wallet: $${userWallet.toFixed(2)}`);
}

// bu ksııdma gecikemlinin test kısmı Asenkron Test
console.log("\n--- Starting Asynchronous Transaction ---");

vend(2, 5.00, handleVendResult);

console.log("...waiting for the machine..."); 

///////////////////////////////////////////////
// --- CHALLENGE TASKS ---

// 1. Stok Ekleme Fonksiyonu
function restockItem(itemId, quantity, callback) {
    console.log(`\n...restocking item ${itemId} with ${quantity} units...`);
    
    // Stok ekleme işlemini 1.5 saniye gecikmeyle simüle ediyoruz.
    setTimeout(() => {
        const itemToRestock = inventory.find(item => item.id === itemId);

        // Ürün bulunamazsa hata döndür.
        if (!itemToRestock) {
            return callback(new Error(`Item with ID ${itemId} not found.`));
        }

        // Stoğu artır.
        itemToRestock.stock += quantity;
        
        // Başarılı olunca callback'i çağır.
        callback(null, itemToRestock);
    }, 1500);
}

// Bu fonksiyon için bir callback handler oluştur
function handleRestockResult(error, item) {
    if (error) {
        console.error("RESTOCK ERROR: " + error.message);
    } else {
        console.log(`SUCCESS! Item "${item.name}" has been restocked. New stock is ${item.stock}.`);
    }
    // Stok ekleme sonrası envanteri tekrar görelim.
    console.log("\n--- Inventory After Restock ---");
    displayInventory();
}

//CHALLENGE TEST BÖLÜMÜ 
// Önce envanterin ilk halı
console.log("--- Initial state before challenges ---");
displayInventory();

// stok tükenmişse
restockItem(5, 10, handleRestockResult);

// Toplu Satın Alma Fonksiyonu
function buyMultiple(itemsArray) {
    console.log("\n--- Attempting to buy multiple items:", itemsArray, "---");

    // .reduce() ile toplam maliyeti hesapla.
    const totalCost = itemsArray.reduce((currentTotal, itemId) => {
        const item = inventory.find(i => i.id === itemId);
        // Eğer ürün varsa fiyatını toplama ekle, yoksa değişmesin
        return item ? currentTotal + item.price : currentTotal;
    }, 0); // Başlangıç değeri 0

    console.log(`Calculated Total Cost: $${totalCost.toFixed(2)}`);

    // Kontroller
    if (totalCost > userWallet) {
        console.error("BULK BUY ERROR: Insufficient funds for this bulk purchase.");
        return;
    }
    

    // Satın alma kısmı
    userWallet -= totalCost; 
    itemsArray.forEach(itemId => {
        const item = inventory.find(i => i.id === itemId);
        if (item) item.stock--; 
    });

    console.log("SUCCESS! Bulk purchase completed.");
}

buyMultiple([1, 4, 3]);

// 
console.log("\n--- Final State After All Operations ---");
displayInventory();
console.log(`Final user wallet: $${userWallet.toFixed(2)}`);

function applyDiscount(discountPercentage) {
    console.log(`\n--- Applying a ${discountPercentage}% discount... ---`);
    

    const discountedInventory = inventory.map(item => {
        const discountedPrice = item.price * (1 - discountPercentage / 100);
        return {
            ...item, 
            price: discountedPrice 
        };
    });

    return discountedInventory;
}

// %20 indirimli fiyatlar
const discountedList = applyDiscount(20);
console.log("Discounted Prices List:");
discountedList.forEach(item => {
    console.log(`Name: ${item.name} | Discounted Price: $${item.price.toFixed(2)}`);
});

console.log("\nOriginal Inventory (Unchanged):");
displayInventory(); // Orijinal envanterin değişip değişmediğine bakıyoruz